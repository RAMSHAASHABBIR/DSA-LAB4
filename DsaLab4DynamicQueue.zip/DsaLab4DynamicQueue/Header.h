#pragma once
#include <iostream>
#include <stdexcept>
#include <queue>
using namespace std;
template<typename T>
class DynamicQueue
{
private:
	int size, capacity, fi, ri;
	T* SQ;
public:
	DynamicQueue()
	{
		size = 0;
		capacity = 1;
		SQ = new T[capacity];
		fi = 0;
		ri = -1;
	}
	bool empty()
	{
		return size == 0;
	}
	bool full()
	{
		return size == capacity;
	}
	void push(T val)
	{
		if (full())
		{
			T* DQ = new T[capacity];
			for (int i=0,c=fi;i<size;i++,c++)
			{
				if (c==capacity)
				{
					c = 0;
				}
				DQ[i] = SQ[c];
			}
			delete[] SQ;
			SQ = DQ;
			capacity = capacity * 2;
			fi = 0;
			ri = size;
		}
		SQ[size] = val;
		size++;
		ri = (ri + 1) % capacity;
	}
	void pop()
	{
		if (empty())
		{
			throw exception("QUEUE IS FULL");
		}
		fi = (fi + 1) % capacity;
		size--;
	}
	T front()
	{
		return SQ[fi];
	}
	T back()
	{
		return SQ[ri];
	}
	void print()
	{
		for (int i = 0;i < size;i++)
		{
			cout << SQ[i] << endl;
		}
	}
};

