#pragma once
#include <iostream>
#include <stdexcept>
#include <queue>
using namespace std;
template<typename T>
class StaticQueue
{
private:
	int size, capacity, fi, ri;
	T* SQ;
public:
	StaticQueue(int cap)
	{
		size = 0;
		capacity = cap;
		SQ = new T[capacity];
		fi = 0;
		ri = -1;
	}
	bool empty()
	{
		return size == 0;
	}
	bool full()
	{
		return size == capacity;
	}
	void push(T val)
	{
		if (full())
		{
			throw exception("QUEUE IS FULL");
		}
		SQ[size] = val;
		size++;
		ri = (ri + 1) % capacity;
	}
	void pop()
	{
		if (empty())
		{
			throw exception("QUEUE IS FULL");
		}
		fi = (fi +1) % capacity;
		size--;
	}
	T front()
	{
		return SQ[fi];
	}
	T back()
	{
		return SQ[ri];
	}
	void print()
	{
		for (int i = 0;i < size;i++)
		{
			cout << SQ[i] << endl;
		}
	}
};
